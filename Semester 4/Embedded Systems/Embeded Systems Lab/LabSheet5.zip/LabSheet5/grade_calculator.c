void main(void) {
	
	int mark = 82;
	char grade; 
	if (mark > 85) {
			grade = 'A';
	}else if(85<mark<=70) {
			grade = 'B';
	}else if(70<mark<=55) {
			grade = 'C'; 
	}else if(54<mark<=40) {
			grade = 'D';
	}else {
			grade = 'F';
	}
}
