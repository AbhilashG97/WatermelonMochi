void main(void) {
	int result;
	int a = 1;
	int b = 0;
	// AND operation
	result = a & b;
	// OR operation
	result = a | b;
	// NOT operation
	result = ~ a;
	// XOR opearation
	result = a ^ b;
	// NAND opeartion
	result = ~ (a & b);
	// SHIFT RIGHT operation
	result =  a >> b;
}
